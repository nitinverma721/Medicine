package com.cognizant.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.*;
import com.cognizant.entity.Admin;
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired 
	private AdminDAO adminDAO;
	public int ValidateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		
		return adminDAO.getAdminDetails(admin);
		
	}
	public boolean registerAdmin(Admin admin) {
		
		return adminDAO.registerAdmin(admin);
	}
	public int checkAdminCredentials(Admin admin) {
		// TODO Auto-generated method stub
		return adminDAO.checkAdmin(admin);
	}

}
