package com.cognizant.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Admin;

@Repository
public class AdminDAOImpl implements AdminDAO {
    
	@Autowired
	private SessionFactory sessionFactory;
	
	public int getAdminDetails(Admin admin) {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Admin o where o.adminId=:adminId");
		query.setString("adminId", admin.getAdminId());
		Query query1=session.createQuery("from Admin o where o.adminId=:adminId And o.adminPassword=:adminPassword");
		query1.setString("adminId",admin.getAdminId());
		query1.setString("adminPassword",admin.getAdminPassword());
		List<Admin> idList=query.list();
		List<Admin> passwordList=query1.list();
		if(idList.isEmpty())
			return 1;
		else if(passwordList.isEmpty())
			return 2;
		else
			return 3;
	}


	public boolean registerAdmin(Admin admin) {
		Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(admin);
		tx.commit();
		session.close();
		return true;
		
	}


	public int checkAdmin(Admin admin) {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Admin o where o.adminContactNo=:adminContactNo");
		query.setString("adminContactNo", admin.getAdminContactNo());
		Query query1=session.createQuery("from Admin o where o.adminEmailId=:adminEmailId");
		query1.setString("adminEmailId",admin.getAdminEmailId());
		List<Admin> contactList=query.list();
		List<Admin> emailList=query1.list();
		if(!contactList.isEmpty()&&emailList.isEmpty())
			return 1;
		else if(contactList.isEmpty()&&!emailList.isEmpty())
			return 2;
		else if(!contactList.isEmpty()&&!emailList.isEmpty())
			return 3;
		return 4;
	}

	

	
}
