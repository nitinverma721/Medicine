package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Admin;
import com.cognizant.service.AdminService;

@Controller
public class AdminController {
	//protected final Log logger=LogFactory.getLog(getClass());

	@Autowired
	private AdminService adminLoginService;
	
	@Autowired@Qualifier("LoginValidator")
	private Validator loginValidator;
	
	@Autowired@Qualifier("RegisterValidator")
	private Validator registerValidator;
	
	@RequestMapping(value="loginadmin.htm",method=RequestMethod.POST)
	public ModelAndView loginAdmin(@ModelAttribute("admin") Admin admin,Errors errors){
		ModelAndView mv=new ModelAndView();
		ValidationUtils.invokeValidator(loginValidator, admin, errors);
		if(errors.hasErrors()){
			mv.setViewName("adminlogin");
		}
		else{
			
			mv.setViewName("home");
		}
		return mv;
	}
	
	@RequestMapping(value="index.htm",method=RequestMethod.GET)
	public String showLogin(){
	//	logger.info("*****sayHello method call");
		return "adminlogin";
	}
	@ModelAttribute("admin")
	public Admin createAdminObject(){
			
		Admin admin=new Admin();
		return admin;
		
	}
	
	@RequestMapping(value="registerUser.htm",method=RequestMethod.POST)
	public ModelAndView registerAdmin(@ModelAttribute("admin") Admin admin,Errors errors) {
		admin.setAdminId("3");
		ValidationUtils.invokeValidator(registerValidator, admin, errors);
		ModelAndView mv=new ModelAndView();
		if(errors.hasErrors()){
			mv.setViewName("register");
		}
		else{
		boolean res=adminLoginService.registerAdmin(admin);
		
		if(res==true)
		{
			mv.setViewName("registersuccess");
		}
		else
		{
			mv.setViewName("register");
		}
		}
		return mv;
				
		
		
	}
	
	
	
	@RequestMapping(value="register.htm",method=RequestMethod.POST)
	public ModelAndView getRegisteration(){
		ModelAndView mv=new ModelAndView();
		List<String> gender=new ArrayList<String>();
		gender.add("Male");
		gender.add("Female");
		mv.addObject("genderList",gender);
		mv.setViewName("register");
		return mv;
		
	}
}
